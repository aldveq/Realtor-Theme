jQuery('.idx-wrapper-page').select2({
        placeholder: 'Select a Page'
        });
